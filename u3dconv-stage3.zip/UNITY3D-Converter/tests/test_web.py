"""Web UI tests: start the real HTTP server and call it over localhost.

As in test_stage2.py, UnityPy is replaced by small fakes, so these tests check
u3dconv's server logic (auth, uploads, routing, repack, ZIP export, cleanup)
and not UnityPy's codecs.

Run:  python -m unittest discover -s tests -v
"""

import io
import json
import os
import sys
import tempfile
import unittest
import urllib.error
import urllib.request
import zipfile
from unittest import mock

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from test_stage2 import FakeEnv, FakeObj, FakeTexture, make_header  # noqa: E402
from PIL import Image  # noqa: E402

from u3dconv import bundle, web  # noqa: E402


def png_bytes(size=(4, 4)):
    buf = io.BytesIO()
    Image.new("RGBA", size, (10, 200, 10, 255)).save(buf, "PNG")
    return buf.getvalue()


class Client:
    def __init__(self, base, token):
        self.base = base
        self.token = token

    def call(self, method, path, body=None, headers=None, token=True, query_token=False):
        url = self.base + path
        if query_token:
            url += ("&" if "?" in url else "?") + "t=" + self.token
        hdrs = dict(headers or {})
        if token:
            hdrs["X-U3D-Token"] = self.token
        req = urllib.request.Request(url, data=body, method=method, headers=hdrs)
        try:
            with urllib.request.urlopen(req, timeout=10) as resp:
                return resp.status, resp.read(), resp.headers
        except urllib.error.HTTPError as exc:
            return exc.code, exc.read(), exc.headers

    def json(self, *args, **kwargs):
        status, data, _ = self.call(*args, **kwargs)
        return status, json.loads(data.decode())


class WebTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.objects = [FakeObj(7, "Texture2D", FakeTexture("hero")),
                        FakeObj(8, "Mesh", object())]
        patcher = mock.patch.object(
            bundle.UnityPy, "load", lambda path: FakeEnv(self.objects)
        )
        patcher.start()
        self.addCleanup(patcher.stop)
        self.handle = web.start_server(
            port=0, workspace=os.path.join(self.tmp.name, "ws"), max_upload_mb=1
        )
        self.addCleanup(self.tmp.cleanup)
        self.addCleanup(self.handle.stop)
        base = self.handle.url.split("/?")[0]
        self.c = Client(base, self.handle.token)

    def upload(self, name="game.unity3d", data=None):
        data = data if data is not None else make_header(1) + b"x"
        return self.c.json("POST", "/api/upload?name=" + name, body=data)

    # -- auth ------------------------------------------------------------------

    def test_index_requires_token(self):
        status, _, _ = self.c.call("GET", "/", token=False)
        self.assertEqual(status, 403)
        status, body, headers = self.c.call("GET", "/", token=False, query_token=True)
        self.assertEqual(status, 200)
        self.assertIn(b"u3dconv", body)
        self.assertIn("default-src 'self'", headers["Content-Security-Policy"])

    def test_api_requires_token_and_rejects_wrong_token(self):
        status, _ = self.c.json("POST", "/api/upload?name=x", body=b"x", token=False)
        self.assertEqual(status, 403)
        status, _, _ = self.c.call("GET", "/", headers={"X-U3D-Token": "wrong"}, token=False)
        self.assertEqual(status, 403)

    # -- upload and inspection ---------------------------------------------------

    def test_upload_summary_and_listings(self):
        status, s = self.upload()
        self.assertEqual(status, 200)
        self.assertEqual(s["counts"], {"Mesh": 1, "Texture2D": 1})
        self.assertEqual(s["header"]["compression"], "LZMA")
        self.assertEqual(s["texture_count"], 1)

        sid = s["id"]
        status, tree = self.c.json("GET", f"/api/session/{sid}/objects")
        self.assertEqual(status, 200)
        self.assertEqual(tree["Texture2D"][0]["name"], "hero")
        status, tree = self.c.json("GET", f"/api/session/{sid}/objects?type=mesh")
        self.assertEqual(list(tree), ["Mesh"])
        status, texs = self.c.json("GET", f"/api/session/{sid}/textures")
        self.assertEqual(texs[0]["path_id"], 7)
        self.assertFalse(texs[0]["replaced"])

    def test_thumbnail_and_full_png(self):
        _, s = self.upload()
        for size in ("thumb", "full"):
            status, data, headers = self.c.call(
                "GET", f"/api/session/{s['id']}/texture/7.png?size={size}"
            )
            self.assertEqual(status, 200)
            self.assertTrue(data.startswith(web.PNG_SIGNATURE))
            self.assertEqual(headers["Content-Type"], "image/png")
        status, _ = self.c.json("GET", f"/api/session/{s['id']}/texture/999.png")
        self.assertEqual(status, 404)

    def test_failed_open_leaves_no_session_folder(self):
        with mock.patch.object(bundle.UnityPy, "load", side_effect=RuntimeError("bad file")):
            status, body = self.upload()
        self.assertEqual(status, 400)
        self.assertIn("could not open", body["error"])
        self.assertEqual(os.listdir(self.handle.app.workspace), [])

    def test_upload_limit(self):
        status, body = self.upload(data=b"x" * (1024 * 1024 + 1))
        self.assertEqual(status, 413)
        self.assertEqual(self.handle.app.sessions, {})

    # -- staging, repack, downloads ---------------------------------------------

    def test_stage_repack_and_download(self):
        _, s = self.upload()
        sid = s["id"]

        status, body = self.c.json("POST", f"/api/session/{sid}/repack", body=b"{}")
        self.assertEqual(status, 400)  # nothing staged yet

        status, r = self.c.json("POST", f"/api/session/{sid}/texture/7/replace",
                                body=png_bytes())
        self.assertEqual(status, 200)
        self.assertEqual(r["staged"], ["texture_7.png"])

        # A second upload for the same texture replaces the first.
        status, r = self.c.json("POST", f"/api/session/{sid}/png?name=hero_7.png",
                                body=png_bytes())
        self.assertEqual(r["staged"], ["hero_7.png"])

        _, texs = self.c.json("GET", f"/api/session/{sid}/textures")
        self.assertTrue(texs[0]["replaced"])

        status, result = self.c.json(
            "POST", f"/api/session/{sid}/repack",
            body=json.dumps({"packer": "lz4"}).encode(),
        )
        self.assertEqual(status, 200)
        self.assertEqual(result["compression"], "LZ4")
        self.assertEqual(result["replaced"], 1)
        self.assertEqual(result["failed"], 0)
        self.assertEqual(result["output_name"], "game_repacked.unity3d")

        status, data, headers = self.c.call("GET", f"/api/session/{sid}/download/bundle")
        self.assertEqual(status, 200)
        self.assertTrue(data.startswith(b"UnityFS"))
        self.assertIn("attachment", headers["Content-Disposition"])

        status, data, _ = self.c.call(
            "GET", f"/api/session/{sid}/download/package.zip?include_pngs=1",
            query_token=True)
        names = zipfile.ZipFile(io.BytesIO(data)).namelist()
        self.assertEqual(sorted(names), ["game_repacked.unity3d", "textures/hero_7.png"])

        status, data, _ = self.c.call("GET", f"/api/session/{sid}/download/textures.zip")
        names = zipfile.ZipFile(io.BytesIO(data)).namelist()
        self.assertEqual(names, ["hero_7.png"])

    def test_bad_inputs(self):
        _, s = self.upload()
        sid = s["id"]
        status, body = self.c.json("POST", f"/api/session/{sid}/png?name=a.png", body=b"not png")
        self.assertEqual(status, 400)
        status, _ = self.c.json("POST", f"/api/session/{sid}/texture/999/replace", body=png_bytes())
        self.assertEqual(status, 404)
        self.c.json("POST", f"/api/session/{sid}/texture/7/replace", body=png_bytes())
        status, body = self.c.json("POST", f"/api/session/{sid}/repack",
                                   body=json.dumps({"packer": "zip"}).encode())
        self.assertEqual(status, 400)
        status, body = self.c.json("POST", f"/api/session/{sid}/repack",
                                   body=json.dumps({"format": "NOPE"}).encode())
        self.assertEqual(status, 400)
        status, body = self.c.json("POST", f"/api/session/{sid}/repack", body=b"[1]")
        self.assertEqual(status, 400)
        status, _ = self.c.json("GET", f"/api/session/{sid}/download/bundle")
        self.assertEqual(status, 404)  # nothing repacked yet

    def test_unknown_and_malicious_session_ids(self):
        for sid in ("nope", "..%2F..%2Fetc", "A" * 20, "../" * 6):
            status, _ = self.c.json("GET", f"/api/session/{sid}")
            self.assertEqual(status, 404, sid)

    def test_delete_session_removes_files(self):
        _, s = self.upload()
        root = os.path.join(self.handle.app.workspace, s["id"])
        self.assertTrue(os.path.isdir(root))
        status, _ = self.c.json("DELETE", f"/api/session/{s['id']}")
        self.assertEqual(status, 200)
        self.assertFalse(os.path.exists(root))
        status, _ = self.c.json("GET", f"/api/session/{s['id']}")
        self.assertEqual(status, 404)

    def test_session_cap_drops_oldest(self):
        first = self.upload()[1]["id"]
        for _ in range(web.MAX_SESSIONS):
            self.upload()
        status, _ = self.c.json("GET", f"/api/session/{first}")
        self.assertEqual(status, 404)
        self.assertLessEqual(len(self.handle.app.sessions), web.MAX_SESSIONS)

    def test_stop_removes_workspace_sessions(self):
        _, s = self.upload()
        root = os.path.join(self.handle.app.workspace, s["id"])
        self.handle.app.close()
        self.assertFalse(os.path.exists(root))


if __name__ == "__main__":
    unittest.main()
