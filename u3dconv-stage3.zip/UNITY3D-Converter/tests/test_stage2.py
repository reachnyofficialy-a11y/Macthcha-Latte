"""Stage 2 tests: texture import/export and bundle repacking.

These tests use small fake objects in place of UnityPy, so they run without a
Unity bundle and without UnityPy's codecs. They check u3dconv's own logic:
file matching, fallbacks, atomic writes, verification, and the CLI. They do
NOT prove that UnityPy's encoders or a real game accept the output; test that
with your own Unity project.

Run:  python -m unittest discover -s tests -v
"""

import enum
import os
import struct
import sys
import tempfile
import types
import unittest
import zipfile
from unittest import mock

try:  # use the real UnityPy when installed, otherwise a minimal stand-in
    import UnityPy  # noqa: F401
    from UnityPy.enums import TextureFormat
except ImportError:
    class TextureFormat(enum.IntEnum):
        RGB24 = 3
        RGBA32 = 4
        ETC2_RGBA8 = 47
        ASTC_RGBA_4x4 = 55

    stub = types.ModuleType("UnityPy")
    stub.load = lambda path: None
    enums = types.ModuleType("UnityPy.enums")
    enums.TextureFormat = TextureFormat
    stub.enums = enums
    sys.modules["UnityPy"] = stub
    sys.modules["UnityPy.enums"] = enums

from PIL import Image

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from u3dconv import bundle, cli, textures  # noqa: E402

LZ4_FLAG = 2


def make_header(flags=LZ4_FLAG):
    return (
        b"UnityFS\x00"
        + struct.pack(">I", 6)
        + b"5.x.x\x00"
        + b"2019.4.0f1\x00"
        + struct.pack(">qIII", 1000, 10, 10, flags)
    )


class FakeType:
    def __init__(self, name):
        self.name = name


class FakeTexture:
    def __init__(self, name, w=4, h=4, fmt=TextureFormat.RGBA32, fail=()):
        self.m_Name = name
        self.m_Width = w
        self.m_Height = h
        self.m_TextureFormat = fmt
        self.m_MipCount = 1
        self.fail = fail
        self.saved = False
        self.applied = None

    @property
    def image(self):
        return Image.new("RGBA", (self.m_Width, self.m_Height), (1, 2, 3, 255))

    def set_image(self, img, target_format=None, mipmap_count=1):
        if target_format in self.fail:
            raise RuntimeError("encoder unavailable")
        self.applied = (img.size, target_format, mipmap_count)
        self.m_Width, self.m_Height = img.size

    def save(self):
        self.saved = True


class FakeObj:
    def __init__(self, path_id, type_name, payload):
        self.path_id = path_id
        self.type = FakeType(type_name)
        self._payload = payload

    def read(self):
        return self._payload

    def get_raw_data(self):
        return b"raw"


class FakeFile:
    def save(self, packer="original"):
        flags = {"none": 0, "lzma": 1, "lz4": 2, "original": 2}[packer]
        return make_header(flags) + b"payload"


class FakeEnv:
    def __init__(self, objects, with_file=True):
        self.objects = objects
        self.file = FakeFile() if with_file else None


def write_png(folder, filename, size=(4, 4)):
    path = os.path.join(folder, filename)
    Image.new("RGBA", size, (200, 0, 0, 255)).save(path)
    return path


class TextureTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.dir = self.tmp.name

    def tearDown(self):
        self.tmp.cleanup()

    def test_parse_path_id(self):
        self.assertEqual(textures.parse_path_id("hero_123"), 123)
        self.assertEqual(textures.parse_path_id("hero_-77"), -77)
        self.assertIsNone(textures.parse_path_id("hero"))

    def test_export_names_include_path_id(self):
        env = FakeEnv([FakeObj(-5, "Texture2D", FakeTexture("My Tex")),
                       FakeObj(6, "Mesh", object())])
        report = textures.export_textures(env, self.dir)
        self.assertEqual(report.written, ["My_Tex_-5.png"])
        self.assertTrue(os.path.isfile(os.path.join(self.dir, "My_Tex_-5.png")))

    def test_export_name_filter(self):
        env = FakeEnv([FakeObj(1, "Texture2D", FakeTexture("a")),
                       FakeObj(2, "Texture2D", FakeTexture("b"))])
        report = textures.export_textures(env, self.dir, names=["B"])
        self.assertEqual(report.written, ["b_2.png"])

    def test_import_matches_by_path_id_and_unique_name(self):
        t1, t2 = FakeTexture("alpha"), FakeTexture("beta")
        env = FakeEnv([FakeObj(1, "Texture2D", t1), FakeObj(2, "Texture2D", t2)])
        write_png(self.dir, "renamed_1.png")
        write_png(self.dir, "beta.png")
        report = textures.import_textures(env, self.dir)
        self.assertEqual(report.replaced, 2)
        self.assertTrue(t1.saved and t2.saved)

    def test_import_ambiguous_and_unknown_files(self):
        env = FakeEnv([FakeObj(1, "Texture2D", FakeTexture("dup")),
                       FakeObj(2, "Texture2D", FakeTexture("dup"))])
        write_png(self.dir, "dup.png")
        write_png(self.dir, "ghost_99.png")
        report = textures.import_textures(env, self.dir)
        self.assertEqual(report.replaced, 0)
        self.assertEqual(len(report.unmatched_files), 2)

    def test_import_size_mismatch(self):
        tex = FakeTexture("a", 4, 4)
        env = FakeEnv([FakeObj(1, "Texture2D", tex)])
        write_png(self.dir, "a_1.png", size=(8, 8))
        report = textures.import_textures(env, self.dir)
        self.assertEqual(report.failed, 1)
        self.assertFalse(tex.saved)
        report = textures.import_textures(env, self.dir, allow_resize=True)
        self.assertEqual(report.replaced, 1)
        self.assertEqual((tex.m_Width, tex.m_Height), (8, 8))

    def test_fallback_to_rgba32(self):
        tex = FakeTexture("a", fmt=TextureFormat.ETC2_RGBA8,
                          fail=(TextureFormat.ETC2_RGBA8,))
        env = FakeEnv([FakeObj(1, "Texture2D", tex)])
        write_png(self.dir, "a_1.png")
        report = textures.import_textures(env, self.dir)
        self.assertEqual(report.results[0].status, "fallback")
        self.assertEqual(tex.applied[1], TextureFormat.RGBA32)
        self.assertTrue(tex.saved)

    def test_no_fallback_fails_cleanly(self):
        tex = FakeTexture("a", fmt=TextureFormat.ETC2_RGBA8,
                          fail=(TextureFormat.ETC2_RGBA8,))
        env = FakeEnv([FakeObj(1, "Texture2D", tex)])
        write_png(self.dir, "a_1.png")
        report = textures.import_textures(env, self.dir, fallback=False)
        self.assertEqual(report.failed, 1)
        self.assertFalse(tex.saved)

    def test_forced_format_is_used(self):
        tex = FakeTexture("a")
        env = FakeEnv([FakeObj(1, "Texture2D", tex)])
        write_png(self.dir, "a_1.png")
        fmt = textures.resolve_texture_format("rgb24")
        textures.import_textures(env, self.dir, target_format=fmt)
        self.assertEqual(tex.applied[1], TextureFormat.RGB24)

    def test_bad_format_name_and_empty_folder(self):
        with self.assertRaises(textures.TextureError):
            textures.resolve_texture_format("NOPE")
        with self.assertRaises(textures.TextureError):
            textures.import_textures(FakeEnv([]), self.dir)


class RepackTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.dir = self.tmp.name
        self.src = os.path.join(self.dir, "src.unity3d")
        with open(self.src, "wb") as fh:
            fh.write(make_header(1) + b"x")
        self.pngs = os.path.join(self.dir, "pngs")
        os.makedirs(self.pngs)
        write_png(self.pngs, "a_1.png")
        self.tex = FakeTexture("a")
        self.objects = [FakeObj(1, "Texture2D", self.tex), FakeObj(2, "Mesh", object())]

    def tearDown(self):
        self.tmp.cleanup()

    def _loader(self, out_count=None):
        count = len(self.objects) if out_count is None else out_count

        def fake_load(path):
            if path == self.src:
                return FakeEnv(self.objects)
            return FakeEnv([FakeObj(i, "Mesh", object()) for i in range(count)])

        return fake_load

    def test_repack_end_to_end(self):
        out = os.path.join(self.dir, "out.unity3d")
        with mock.patch.object(bundle.UnityPy, "load", self._loader()):
            result = bundle.repack_bundle(self.src, out, self.pngs, packer="lz4")
        self.assertEqual(result.verify.header.compression, "LZ4")
        self.assertEqual(result.verify.object_count, 2)
        self.assertTrue(os.path.isfile(out))
        self.assertFalse(os.path.exists(out + ".tmp"))

    def test_verification_failure_deletes_output(self):
        out = os.path.join(self.dir, "out.unity3d")
        with mock.patch.object(bundle.UnityPy, "load", self._loader(out_count=1)):
            with self.assertRaises(bundle.BundleError):
                bundle.repack_bundle(self.src, out, self.pngs)
        self.assertFalse(os.path.exists(out))

    def test_refuses_same_path_existing_output_and_non_unityfs(self):
        with mock.patch.object(bundle.UnityPy, "load", self._loader()):
            with self.assertRaises(bundle.BundleError):
                bundle.repack_bundle(self.src, self.src, self.pngs)
            existing = os.path.join(self.dir, "exists.unity3d")
            open(existing, "wb").close()
            with self.assertRaises(bundle.BundleError):
                bundle.repack_bundle(self.src, existing, self.pngs)
            bad = os.path.join(self.dir, "bad.bin")
            with open(bad, "wb") as fh:
                fh.write(b"not a bundle")
            with self.assertRaises(bundle.BundleError):
                bundle.repack_bundle(bad, os.path.join(self.dir, "o"), self.pngs)

    def test_nothing_replaced_writes_nothing(self):
        out = os.path.join(self.dir, "out.unity3d")
        empty = os.path.join(self.dir, "ghosts")
        os.makedirs(empty)
        write_png(empty, "ghost_99.png")
        with mock.patch.object(bundle.UnityPy, "load", self._loader()):
            with self.assertRaises(bundle.BundleError):
                bundle.repack_bundle(self.src, out, empty)
        self.assertFalse(os.path.exists(out))

    def test_save_bundle_rejects_bad_packer_and_missing_file(self):
        with self.assertRaises(bundle.BundleError):
            bundle.save_bundle(FakeEnv([]), os.path.join(self.dir, "x"), packer="zip")
        with self.assertRaises(bundle.BundleError):
            bundle.save_bundle(FakeEnv([], with_file=False), os.path.join(self.dir, "x"))


class CliTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.dir = self.tmp.name
        self.src = os.path.join(self.dir, "src.unity3d")
        with open(self.src, "wb") as fh:
            fh.write(make_header(1) + b"x")
        self.pngs = os.path.join(self.dir, "pngs")
        os.makedirs(self.pngs)
        write_png(self.pngs, "a_1.png")
        self.objects = [FakeObj(1, "Texture2D", FakeTexture("a"))]

    def tearDown(self):
        self.tmp.cleanup()

    def _loader(self):
        def fake_load(path):
            return FakeEnv(self.objects)
        return fake_load

    def test_cli_repack_with_zip(self):
        out = os.path.join(self.dir, "out.unity3d")
        zip_path = os.path.join(self.dir, "share.zip")
        with mock.patch.object(bundle.UnityPy, "load", self._loader()):
            code = cli.main(["repack", self.src, "--textures", self.pngs,
                             "-o", out, "--zip", zip_path])
        self.assertEqual(code, 0)
        with zipfile.ZipFile(zip_path) as zf:
            self.assertEqual(zf.namelist(), ["out.unity3d"])

    def test_cli_convert_export_and_list(self):
        out = os.path.join(self.dir, "png_out")
        with mock.patch.object(bundle.UnityPy, "load", self._loader()):
            self.assertEqual(cli.main(["convert", self.src, "-o", out, "--zip"]), 0)
            self.assertEqual(cli.main(["convert", self.src, "--list"]), 0)
        self.assertTrue(os.path.isfile(out + ".zip"))
        self.assertTrue(os.path.isfile(os.path.join(out, "a_1.png")))

    def test_cli_repack_bad_format_name(self):
        out = os.path.join(self.dir, "out.unity3d")
        code = cli.main(["repack", self.src, "--textures", self.pngs,
                         "-o", out, "--format", "NOPE"])
        self.assertEqual(code, 2)


if __name__ == "__main__":
    unittest.main()
