"""u3dconv: inspect, extract, convert and repack Unity3D UnityFS bundles."""

from .constants import APP_VERSION as __version__

__all__ = ["__version__"]
