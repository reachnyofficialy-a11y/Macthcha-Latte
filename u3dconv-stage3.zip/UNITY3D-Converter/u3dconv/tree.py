"""Hierarchical views of bundle contents.

Objects are grouped by type. Dependency edges and editing are planned for
the repacking stage.
"""

from collections import defaultdict
from typing import Dict, Iterable, List

from .bundle import ObjectInfo


def group_by_type(objects: Iterable[ObjectInfo]) -> Dict[str, List[ObjectInfo]]:
    groups: Dict[str, List[ObjectInfo]] = defaultdict(list)
    for obj in objects:
        groups[obj.type_name].append(obj)
    for items in groups.values():
        items.sort(key=lambda o: (o.name.lower(), o.path_id))
    return dict(sorted(groups.items()))


def render_tree(objects: Iterable[ObjectInfo]) -> List[str]:
    """Return text lines drawing the object tree."""
    groups = group_by_type(objects)
    lines: List[str] = []
    for g_index, (type_name, items) in enumerate(groups.items()):
        last_group = g_index == len(groups) - 1
        branch = "└── " if last_group else "├── "
        lines.append(f"{branch}{type_name} ({len(items)})")
        prefix = "    " if last_group else "│   "
        for i, obj in enumerate(items):
            leaf = "└── " if i == len(items) - 1 else "├── "
            label = obj.name or "(unnamed)"
            lines.append(f"{prefix}{leaf}{label} [#{obj.path_id}]")
    return lines


def tree_to_dict(objects: Iterable[ObjectInfo]) -> dict:
    return {
        type_name: [obj.to_dict() for obj in items]
        for type_name, items in group_by_type(objects).items()
    }
