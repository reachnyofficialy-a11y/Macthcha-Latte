"""Terminal output helpers: status lines, tables, and simple formatting."""

import os
import sys

_COLOR = sys.stdout.isatty() and "NO_COLOR" not in os.environ
_CODES = {"green": "32", "yellow": "33", "red": "31", "bold": "1"}


def _paint(text, color):
    if not _COLOR:
        return text
    return f"\033[{_CODES[color]}m{text}\033[0m"


def heading(message):
    print(_paint(message, "bold"))


def ok(message):
    print(_paint("OK", "green"), message)


def warn(message):
    print(_paint("WARN", "yellow"), message, file=sys.stderr)


def error(message):
    print(_paint("ERROR", "red"), message, file=sys.stderr)


def table(headers, rows):
    """Return a plain-text table as a string."""
    headers = [str(h) for h in headers]
    rows = [[str(c) for c in row] for row in rows]
    widths = [
        max([len(headers[i])] + [len(row[i]) for row in rows])
        for i in range(len(headers))
    ]

    def fmt(cells):
        return "  ".join(cell.ljust(widths[i]) for i, cell in enumerate(cells))

    lines = [fmt(headers), fmt(["-" * w for w in widths])]
    lines.extend(fmt(row) for row in rows)
    return "\n".join(lines)
