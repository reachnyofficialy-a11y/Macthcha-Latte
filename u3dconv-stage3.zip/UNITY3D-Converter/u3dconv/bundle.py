"""UnityFS bundle parsing, extraction, and LZ4 repacking.

Header parsing is done here directly so the tool can report bundle details
without loading the whole file. Object parsing and bundle writing are
delegated to UnityPy.

Stage 1: read-only (header, list, extract).
Stage 2: save_bundle / verify_bundle / repack_bundle for writing modified
         bundles back out.
"""

from __future__ import annotations

import os
import re
import struct
from dataclasses import asdict, dataclass, field
from typing import Iterable, List, Optional

import UnityPy

from .constants import (
    AUDIO_TYPES,
    COMPRESSION_MASK,
    COMPRESSION_NAMES,
    DEFAULT_PACKER,
    PACKER_CHOICES,
    TEXTURE_TYPES,
    UNITYFS_SIGNATURE,
)


class BundleError(Exception):
    """Raised when a file cannot be opened, parsed, saved, or verified."""


@dataclass
class UnityFSHeader:
    version: int
    unity_version: str
    unity_revision: str
    bundle_size: int
    compressed_blocks_info_size: int
    uncompressed_blocks_info_size: int
    flags: int

    @property
    def compression(self) -> str:
        return COMPRESSION_NAMES.get(self.flags & COMPRESSION_MASK, "unknown")


@dataclass
class ObjectInfo:
    path_id: int
    type_name: str
    name: str

    def to_dict(self) -> dict:
        return asdict(self)


@dataclass
class ExtractReport:
    extracted: int = 0
    skipped: int = 0
    errors: List[str] = field(default_factory=list)


@dataclass
class VerifyResult:
    header: UnityFSHeader
    object_count: int
    unreadable: List[int] = field(default_factory=list)


@dataclass
class RepackResult:
    output_path: str
    output_size: int
    import_report: object  # textures.ImportReport (lazy import avoids a cycle)
    verify: VerifyResult


# ---------------------------------------------------------------------------
# Header parsing
# ---------------------------------------------------------------------------

def _read_exact(fh, count: int) -> bytes:
    data = fh.read(count)
    if len(data) != count:
        raise BundleError("Unexpected end of file while reading header")
    return data


def _read_cstring(fh, limit: int = 512) -> str:
    buf = bytearray()
    while len(buf) < limit:
        ch = fh.read(1)
        if not ch:
            raise BundleError("Unexpected end of file while reading header string")
        if ch == b"\x00":
            return buf.decode("utf-8", errors="replace")
        buf += ch
    raise BundleError("Header string too long; file is probably not a UnityFS bundle")


def read_unityfs_header(path: str) -> Optional[UnityFSHeader]:
    """Return the UnityFS header, or None if the file is not a UnityFS bundle."""
    with open(path, "rb") as fh:
        if fh.read(len(UNITYFS_SIGNATURE)) != UNITYFS_SIGNATURE:
            return None
        (version,) = struct.unpack(">I", _read_exact(fh, 4))
        unity_version = _read_cstring(fh)
        unity_revision = _read_cstring(fh)
        bundle_size, c_info, u_info, flags = struct.unpack(
            ">qIII", _read_exact(fh, 20)
        )
    return UnityFSHeader(
        version=version,
        unity_version=unity_version,
        unity_revision=unity_revision,
        bundle_size=bundle_size,
        compressed_blocks_info_size=c_info,
        uncompressed_blocks_info_size=u_info,
        flags=flags,
    )


# ---------------------------------------------------------------------------
# Loading and listing
# ---------------------------------------------------------------------------

def load_environment(path: str):
    """Open a bundle or serialized asset file with UnityPy."""
    if not os.path.isfile(path):
        raise BundleError(f"File not found: {path}")
    try:
        return UnityPy.load(path)
    except Exception as exc:  # UnityPy raises a variety of exception types
        raise BundleError(f"UnityPy could not open {path}: {exc}") from exc


def _safe_read(obj):
    try:
        return obj.read()
    except Exception:
        return None


def _object_name(data) -> str:
    name = getattr(data, "m_Name", "") if data is not None else ""
    return str(name or "")


def sanitize_name(name: str, max_length: int = 120) -> str:
    """Make a string safe to use as a file name on every platform."""
    cleaned = re.sub(r"[^A-Za-z0-9._-]+", "_", name).strip("._")
    return cleaned[:max_length] or "unnamed"


def list_objects(env) -> List[ObjectInfo]:
    """Return one ObjectInfo per object in the environment."""
    result = []
    for obj in env.objects:
        data = _safe_read(obj)
        result.append(
            ObjectInfo(
                path_id=obj.path_id,
                type_name=obj.type.name,
                name=_object_name(data),
            )
        )
    return result


def count_by_type(objects: Iterable[ObjectInfo]) -> dict:
    counts: dict = {}
    for obj in objects:
        counts[obj.type_name] = counts.get(obj.type_name, 0) + 1
    return dict(sorted(counts.items()))


# ---------------------------------------------------------------------------
# Extraction (Stage 1)
# ---------------------------------------------------------------------------

def _write_raw(obj, out_dir: str, type_name: str, base: str) -> None:
    target_dir = os.path.join(out_dir, "raw", sanitize_name(type_name))
    os.makedirs(target_dir, exist_ok=True)
    with open(os.path.join(target_dir, base + ".bin"), "wb") as fh:
        fh.write(obj.get_raw_data())


def _save_texture(data, out_dir: str, base: str) -> None:
    image = data.image  # UnityPy decodes ASTC, PVRTC, ETC2 and RGBA here
    if image is None:
        raise ValueError("texture decoded to nothing")
    target_dir = os.path.join(out_dir, "textures")
    os.makedirs(target_dir, exist_ok=True)
    image.save(os.path.join(target_dir, base + ".png"), "PNG")


def _save_audio(data, out_dir: str, base: str) -> int:
    samples = getattr(data, "samples", None) or {}
    if not samples:
        raise ValueError("no audio samples")
    target_dir = os.path.join(out_dir, "audio")
    os.makedirs(target_dir, exist_ok=True)
    for sample_name, blob in samples.items():
        stem = sanitize_name(os.path.splitext(sample_name)[0])
        ext = os.path.splitext(sample_name)[1] or ".bin"
        with open(os.path.join(target_dir, f"{base}_{stem}{ext}"), "wb") as fh:
            fh.write(blob)
    return len(samples)


def extract_objects(
    env,
    out_dir: str,
    type_filter: Optional[Iterable[str]] = None,
    raw_only: bool = False,
) -> ExtractReport:
    """Extract objects to out_dir.

    Textures become PNG files and audio becomes sample files. Anything else,
    and any texture that fails to decode, is saved as raw bytes so no data
    is lost.
    """
    wanted = {t.lower() for t in type_filter} if type_filter else None
    report = ExtractReport()
    os.makedirs(out_dir, exist_ok=True)

    for obj in env.objects:
        type_name = obj.type.name
        if wanted is not None and type_name.lower() not in wanted:
            report.skipped += 1
            continue

        try:
            data = obj.read()
            name = _object_name(data) or f"{type_name}_{obj.path_id}"
            base = f"{sanitize_name(name)}_{obj.path_id}"

            if raw_only:
                _write_raw(obj, out_dir, type_name, base)
            elif type_name in TEXTURE_TYPES:
                try:
                    _save_texture(data, out_dir, base)
                except Exception as tex_exc:
                    report.errors.append(
                        f"{type_name} {obj.path_id} decoded as raw: {tex_exc}"
                    )
                    _write_raw(obj, out_dir, type_name, base)
            elif type_name in AUDIO_TYPES:
                try:
                    _save_audio(data, out_dir, base)
                except Exception as audio_exc:
                    report.errors.append(
                        f"{type_name} {obj.path_id} decoded as raw: {audio_exc}"
                    )
                    _write_raw(obj, out_dir, type_name, base)
            else:
                _write_raw(obj, out_dir, type_name, base)

            report.extracted += 1
        except Exception as exc:
            report.errors.append(f"{type_name} {obj.path_id}: {exc}")

    return report


# ---------------------------------------------------------------------------
# Saving and repacking (Stage 2)
# ---------------------------------------------------------------------------

def save_bundle(
    env,
    out_path: str,
    packer: str = DEFAULT_PACKER,
    overwrite: bool = False,
) -> int:
    """Serialize the loaded bundle to out_path. Returns the size in bytes.

    The bytes are written to a temporary file first and moved into place, so
    a failure never leaves a half-written bundle at out_path.
    """
    if packer not in PACKER_CHOICES:
        raise BundleError(
            f"Unknown packer '{packer}'. Choose one of: {', '.join(PACKER_CHOICES)}"
        )

    bundle_file = getattr(env, "file", None)
    if bundle_file is None or not hasattr(bundle_file, "save"):
        raise BundleError(
            "Nothing to save: the input was not loaded as a single UnityFS "
            "bundle. Repacking supports one bundle file at a time."
        )

    if os.path.exists(out_path) and not overwrite:
        raise BundleError(f"Output already exists: {out_path} (use --force to replace)")

    try:
        data = bundle_file.save(packer=packer)
    except Exception as exc:
        raise BundleError(
            f"UnityPy could not save the bundle with packer '{packer}': {exc}"
        ) from exc

    out_dir = os.path.dirname(os.path.abspath(out_path))
    tmp_path = out_path + ".tmp"
    try:
        os.makedirs(out_dir, exist_ok=True)
        with open(tmp_path, "wb") as fh:
            fh.write(data)
        os.replace(tmp_path, out_path)
    except OSError as exc:
        if os.path.exists(tmp_path):
            try:
                os.remove(tmp_path)
            except OSError:
                pass
        raise BundleError(f"Could not write {out_path}: {exc}") from exc

    return len(data)


def verify_bundle(path: str, expected_objects: Optional[int] = None) -> VerifyResult:
    """Re-open a saved bundle and check that it is structurally sound.

    This confirms the header is valid UnityFS, UnityPy can load it, the object
    count matches, and every object's type tree can be parsed. It cannot prove
    that a game will accept the bundle; test in your own project to be sure.
    """
    try:
        header = read_unityfs_header(path)
    except (OSError, BundleError) as exc:
        raise BundleError(f"Could not read header of {path}: {exc}") from exc
    if header is None:
        raise BundleError(f"{path} does not start with a UnityFS signature")

    env = load_environment(path)
    count = 0
    unreadable: List[int] = []
    for obj in env.objects:
        count += 1
        if _safe_read(obj) is None:
            unreadable.append(obj.path_id)

    if expected_objects is not None and count != expected_objects:
        raise BundleError(
            f"Object count changed during repack: expected {expected_objects}, "
            f"found {count}"
        )
    return VerifyResult(header=header, object_count=count, unreadable=unreadable)


def repack_bundle(
    src_path: str,
    out_path: str,
    png_dir: str,
    packer: str = DEFAULT_PACKER,
    target_format=None,
    allow_resize: bool = False,
    fallback: bool = True,
    overwrite: bool = False,
) -> RepackResult:
    """Replace textures in src_path with PNGs from png_dir and save a new bundle.

    Steps: load, import PNGs into matching Texture2D objects, save with the
    chosen packer, then verify the written file. If verification fails the
    output is deleted so a bad bundle is never left behind.
    """
    # Imported here because textures.py imports helpers from this module.
    from .textures import TextureError, import_textures

    if os.path.exists(out_path) and os.path.samefile(src_path, out_path):
        raise BundleError("Output path is the same as the input; choose a different -o")

    try:
        header = read_unityfs_header(src_path)
    except OSError as exc:
        raise BundleError(f"Could not read {src_path}: {exc}") from exc
    if header is None:
        raise BundleError(
            "Repacking supports UnityFS bundles only (file does not start with "
            "a UnityFS signature)."
        )

    env = load_environment(src_path)
    expected = sum(1 for _ in env.objects)

    try:
        report = import_textures(
            env,
            png_dir,
            target_format=target_format,
            allow_resize=allow_resize,
            fallback=fallback,
        )
    except TextureError as exc:
        raise BundleError(str(exc)) from exc

    if report.replaced == 0:
        raise BundleError("No textures were replaced, so nothing was saved.")

    size = save_bundle(env, out_path, packer=packer, overwrite=overwrite)

    try:
        verification = verify_bundle(out_path, expected_objects=expected)
    except BundleError as exc:
        try:
            os.remove(out_path)
        except OSError:
            pass
        raise BundleError(
            f"Repacked bundle failed verification and was deleted: {exc}"
        ) from exc

    return RepackResult(
        output_path=out_path,
        output_size=size,
        import_report=report,
        verify=verification,
    )
