"""Texture2D export to PNG and PNG import back into Texture2D objects.

Decoding and encoding of GPU formats (ASTC, PVRTC, ETC2, DXT, RGBA) is done by
UnityPy. This module adds the workflow around it: matching PNG files to
textures, size checks, format preservation, and an RGBA32 fallback when a
GPU-format encoder is unavailable or fails.

File naming: exported PNGs are named <name>_<path_id>.png. On import the
trailing _<path_id> is used to match a PNG to its texture, so you can rename
the part before it freely. Files without a path ID match by texture name, but
only when exactly one texture has that name.
"""

from __future__ import annotations

import inspect
import os
import re
from dataclasses import dataclass, field
from typing import Iterable, List, Optional

from PIL import Image
from UnityPy.enums import TextureFormat

from .bundle import sanitize_name
from .constants import FALLBACK_TEXTURE_FORMAT

_PATH_ID_RE = re.compile(r"_(-?\d+)$")


class TextureError(Exception):
    """Raised for problems that stop a texture operation as a whole."""


@dataclass
class TextureInfo:
    path_id: int
    name: str
    format_name: str
    width: int
    height: int
    mip_count: int


@dataclass
class ExportReport:
    written: List[str] = field(default_factory=list)
    errors: List[str] = field(default_factory=list)


@dataclass
class TextureResult:
    path_id: int
    name: str
    status: str  # "ok", "fallback", or "failed"
    detail: str = ""


@dataclass
class ImportReport:
    results: List[TextureResult] = field(default_factory=list)
    unmatched_files: List[str] = field(default_factory=list)

    @property
    def replaced(self) -> int:
        return sum(1 for r in self.results if r.status in ("ok", "fallback"))

    @property
    def failed(self) -> int:
        return sum(1 for r in self.results if r.status == "failed")


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def format_name(fmt) -> str:
    """Readable name for a TextureFormat enum member or raw integer."""
    name = getattr(fmt, "name", None)
    return str(name) if name else str(fmt)


def resolve_texture_format(name: str):
    """Look up a UnityPy TextureFormat member by name (case-insensitive)."""
    wanted = name.strip().lower()
    for member_name, member in TextureFormat.__members__.items():
        if member_name.lower() == wanted:
            return member
    raise TextureError(
        f"Unknown texture format '{name}'. Use a UnityPy TextureFormat name, "
        "for example RGBA32, RGB24 or ETC2_RGBA8."
    )


def _safe_read(obj):
    try:
        return obj.read()
    except Exception:
        return None


def _texture_objects(env):
    """Yield (object, texture) pairs for every readable Texture2D."""
    for obj in env.objects:
        if obj.type.name != "Texture2D":
            continue
        tex = _safe_read(obj)
        if tex is not None:
            yield obj, tex


def parse_path_id(stem: str) -> Optional[int]:
    """Return the trailing _<path_id> number of a file name stem, if any."""
    match = _PATH_ID_RE.search(stem)
    return int(match.group(1)) if match else None


def collect_png_files(png_dir: str) -> List[str]:
    """All .png files under png_dir (recursive), sorted for stable output."""
    found = []
    for root, _dirs, files in os.walk(png_dir):
        for name in files:
            if name.lower().endswith(".png"):
                found.append(os.path.join(root, name))
    return sorted(found)


# ---------------------------------------------------------------------------
# Listing and export
# ---------------------------------------------------------------------------

def list_textures(env) -> List[TextureInfo]:
    infos = []
    for obj, tex in _texture_objects(env):
        infos.append(
            TextureInfo(
                path_id=obj.path_id,
                name=str(getattr(tex, "m_Name", "") or ""),
                format_name=format_name(getattr(tex, "m_TextureFormat", "?")),
                width=int(getattr(tex, "m_Width", 0) or 0),
                height=int(getattr(tex, "m_Height", 0) or 0),
                mip_count=int(getattr(tex, "m_MipCount", 1) or 1),
            )
        )
    return infos


def export_textures(
    env, out_dir: str, names: Optional[Iterable[str]] = None
) -> ExportReport:
    """Write every Texture2D (optionally filtered by name) as <name>_<id>.png."""
    wanted = {n.lower() for n in names} if names else None
    report = ExportReport()
    os.makedirs(out_dir, exist_ok=True)

    for obj in env.objects:
        if obj.type.name != "Texture2D":
            continue
        tex = _safe_read(obj)
        if tex is None:
            report.errors.append(f"Texture2D {obj.path_id}: could not be read")
            continue

        name = str(getattr(tex, "m_Name", "") or "")
        if wanted is not None and name.lower() not in wanted:
            continue

        label = f"{name or 'texture'} [{obj.path_id}]"
        try:
            image = tex.image
            if image is None:
                raise ValueError("decoded to nothing")
            filename = f"{sanitize_name(name or 'texture')}_{obj.path_id}.png"
            image.save(os.path.join(out_dir, filename), "PNG")
            report.written.append(filename)
        except Exception as exc:
            fmt = format_name(getattr(tex, "m_TextureFormat", "?"))
            report.errors.append(f"{label} ({fmt}): {exc}")

    return report


# ---------------------------------------------------------------------------
# Import
# ---------------------------------------------------------------------------

def _apply_image(tex, image, fmt, mip_count: int) -> None:
    """Encode `image` into `tex`, handling both old and new UnityPy APIs.

    Newer UnityPy: Texture2D.set_image(img, target_format=..., mipmap_count=...)
    Older UnityPy: assign Texture2D.image after setting m_TextureFormat.
    """
    setter = getattr(tex, "set_image", None)
    if callable(setter):
        kwargs = {}
        try:
            params = inspect.signature(setter).parameters
        except (TypeError, ValueError):
            params = {}
        if fmt is not None and "target_format" in params:
            kwargs["target_format"] = fmt
        if "mipmap_count" in params:
            kwargs["mipmap_count"] = mip_count
        setter(image, **kwargs)
    else:
        if fmt is not None:
            tex.m_TextureFormat = fmt
        tex.image = image


def _replace_one(
    obj,
    tex,
    png_path: str,
    target_format,
    allow_resize: bool,
    fallback: bool,
) -> TextureResult:
    name = str(getattr(tex, "m_Name", "") or "")
    pid = obj.path_id

    try:
        with Image.open(png_path) as opened:
            image = opened.convert("RGBA")
    except Exception as exc:
        return TextureResult(pid, name, "failed", f"cannot read PNG: {exc}")

    orig_size = (int(tex.m_Width), int(tex.m_Height))
    if image.size != orig_size and not allow_resize:
        return TextureResult(
            pid,
            name,
            "failed",
            f"PNG is {image.size[0]}x{image.size[1]} but the texture is "
            f"{orig_size[0]}x{orig_size[1]} (use --allow-resize to change it)",
        )

    fmt = target_format if target_format is not None else tex.m_TextureFormat
    mips = int(getattr(tex, "m_MipCount", 1) or 1)

    def attempt(use_fmt) -> None:
        _apply_image(tex, image, use_fmt, mips)
        if (int(tex.m_Width), int(tex.m_Height)) != image.size:
            tex.m_Width, tex.m_Height = image.size
        tex.save()

    try:
        attempt(fmt)
        return TextureResult(pid, name, "ok", f"{format_name(fmt)} {image.size[0]}x{image.size[1]}")
    except Exception as first_error:
        fallback_fmt = resolve_texture_format(FALLBACK_TEXTURE_FORMAT)
        if not fallback or format_name(fmt) == format_name(fallback_fmt):
            return TextureResult(
                pid, name, "failed", f"encoding as {format_name(fmt)} failed: {first_error}"
            )
        # Nothing was written to the bundle yet (save() is the last step), so
        # the object is still intact and we can retry with plain RGBA32.
        try:
            attempt(fallback_fmt)
            return TextureResult(
                pid,
                name,
                "fallback",
                f"{format_name(fmt)} encoding failed ({first_error}); "
                f"saved as {format_name(fallback_fmt)} instead",
            )
        except Exception as second_error:
            return TextureResult(
                pid,
                name,
                "failed",
                f"{format_name(fmt)} failed ({first_error}); "
                f"{format_name(fallback_fmt)} fallback also failed ({second_error})",
            )


def import_textures(
    env,
    png_dir: str,
    target_format=None,
    allow_resize: bool = False,
    fallback: bool = True,
) -> ImportReport:
    """Replace Texture2D objects in env with PNGs found in png_dir.

    Each texture is handled independently: one failure never stops the rest.
    The caller decides whether to save the bundle based on the returned report.
    """
    if not os.path.isdir(png_dir):
        raise TextureError(f"Texture folder not found: {png_dir}")
    files = collect_png_files(png_dir)
    if not files:
        raise TextureError(f"No .png files found in {png_dir}")

    by_id = {}
    by_name = {}
    for obj, tex in _texture_objects(env):
        by_id[obj.path_id] = (obj, tex)
        name = str(getattr(tex, "m_Name", "") or "").lower()
        by_name.setdefault(name, []).append(obj.path_id)

    report = ImportReport()
    used = set()

    for path in files:
        base = os.path.basename(path)
        stem = os.path.splitext(base)[0]
        pid = parse_path_id(stem)

        match = None
        if pid is not None and pid in by_id:
            match = pid
        else:
            candidates = by_name.get(stem.lower(), [])
            if len(candidates) == 1:
                match = candidates[0]
            elif len(candidates) > 1:
                report.unmatched_files.append(
                    f"{base}: {len(candidates)} textures share this name; "
                    "add _<path_id> to the file name"
                )
                continue

        if match is None:
            report.unmatched_files.append(f"{base}: no matching texture in the bundle")
            continue
        if match in used:
            report.unmatched_files.append(
                f"{base}: texture {match} was already replaced by another file"
            )
            continue

        used.add(match)
        obj, tex = by_id[match]
        report.results.append(
            _replace_one(obj, tex, path, target_format, allow_resize, fallback)
        )

    return report
