"""Command-line interface for u3dconv (Stage 2)."""

from __future__ import annotations

import argparse
import json
import os
import sys
import zipfile
from typing import List, Optional

from . import console
from .bundle import (
    BundleError,
    count_by_type,
    extract_objects,
    list_objects,
    load_environment,
    read_unityfs_header,
    repack_bundle,
)
from .constants import (
    APP_VERSION,
    DEFAULT_OUTPUT_DIR,
    DEFAULT_PACKER,
    DEFAULT_TEXTURE_DIR,
    PACKER_CHOICES,
)
from .tree import render_tree, tree_to_dict


# ---------------------------------------------------------------------------
# ZIP export
# ---------------------------------------------------------------------------

def make_zip(source: str, zip_path: str) -> int:
    """Zip a folder (recursively) or a single file. Returns files written."""
    count = 0
    abs_zip = os.path.abspath(zip_path)
    os.makedirs(os.path.dirname(abs_zip) or ".", exist_ok=True)
    with zipfile.ZipFile(zip_path, "w", compression=zipfile.ZIP_DEFLATED) as zf:
        if os.path.isfile(source):
            zf.write(source, os.path.basename(source))
            return 1
        for root, _dirs, files in os.walk(source):
            for name in files:
                full = os.path.join(root, name)
                if os.path.abspath(full) == abs_zip:
                    continue
                zf.write(full, os.path.relpath(full, source))
                count += 1
    return count


def _maybe_zip(args, source: str) -> int:
    """Handle --zip for a command. Returns 0 on success or when not requested."""
    if args.zip is None:
        return 0
    zip_path = args.zip or f"{source.rstrip(os.sep)}.zip"
    try:
        files = make_zip(source, zip_path)
    except OSError as exc:
        console.error(f"Could not write ZIP: {exc}")
        return 1
    console.ok(f"Wrote {files} file(s) to {zip_path}")
    return 0


# ---------------------------------------------------------------------------
# Stage 1 commands
# ---------------------------------------------------------------------------

def cmd_info(args) -> int:
    try:
        header = read_unityfs_header(args.file)
    except (OSError, BundleError) as exc:
        console.error(str(exc))
        return 1

    if header is None:
        console.warn("Not a UnityFS bundle; it may be a serialized asset file.")
    else:
        console.heading("UnityFS bundle")
        print(
            console.table(
                ["Field", "Value"],
                [
                    ["Format version", header.version],
                    ["Unity version", header.unity_version],
                    ["Unity revision", header.unity_revision],
                    ["Bundle size", f"{header.bundle_size:,} bytes"],
                    ["Compression", header.compression],
                    [
                        "Blocks info (compressed / uncompressed)",
                        f"{header.compressed_blocks_info_size:,} / "
                        f"{header.uncompressed_blocks_info_size:,} bytes",
                    ],
                ],
            )
        )
        print()

    try:
        env = load_environment(args.file)
    except BundleError as exc:
        console.error(str(exc))
        return 1

    objects = list_objects(env)
    console.heading(f"Objects: {len(objects)}")
    counts = count_by_type(objects)
    print(console.table(["Type", "Count"], [[t, c] for t, c in counts.items()]))
    return 0


def cmd_list(args) -> int:
    try:
        env = load_environment(args.file)
    except BundleError as exc:
        console.error(str(exc))
        return 1

    objects = list_objects(env)
    if args.type:
        wanted = {t.lower() for t in args.type}
        objects = [o for o in objects if o.type_name.lower() in wanted]

    if args.json:
        print(json.dumps(tree_to_dict(objects), indent=2, ensure_ascii=False))
    else:
        if not objects:
            console.warn("No matching objects.")
            return 0
        for line in render_tree(objects):
            print(line)
    return 0


def cmd_extract(args) -> int:
    try:
        env = load_environment(args.file)
    except BundleError as exc:
        console.error(str(exc))
        return 1

    out_dir = args.output or DEFAULT_OUTPUT_DIR
    report = extract_objects(
        env, out_dir, type_filter=args.type, raw_only=args.raw
    )

    console.ok(f"Extracted {report.extracted} object(s) to {out_dir}")
    if report.skipped:
        console.heading(f"Skipped {report.skipped} object(s) by --type filter")
    for message in report.errors:
        console.warn(message)

    return _maybe_zip(args, out_dir)


# ---------------------------------------------------------------------------
# Stage 2 commands
# ---------------------------------------------------------------------------

def cmd_convert(args) -> int:
    """Export Texture2D objects to PNG (or just list them)."""
    from .textures import export_textures, list_textures

    try:
        env = load_environment(args.file)
    except BundleError as exc:
        console.error(str(exc))
        return 1

    if args.list:
        infos = list_textures(env)
        if not infos:
            console.warn("No Texture2D objects found.")
            return 0
        print(
            console.table(
                ["Path ID", "Name", "Format", "Size", "Mips"],
                [
                    [t.path_id, t.name or "(unnamed)", t.format_name,
                     f"{t.width}x{t.height}", t.mip_count]
                    for t in infos
                ],
            )
        )
        return 0

    out_dir = args.output or DEFAULT_TEXTURE_DIR
    report = export_textures(env, out_dir, names=args.name)

    if not report.written and not report.errors:
        console.warn("No matching textures to export.")
        return 0

    console.ok(f"Exported {len(report.written)} texture(s) to {out_dir}")
    for message in report.errors:
        console.warn(message)

    code = _maybe_zip(args, out_dir) if report.written else 0
    if report.errors and not report.written:
        return 1
    return code


def cmd_repack(args) -> int:
    """Import PNGs into a bundle's textures and save a new bundle."""
    from .textures import TextureError, format_name, resolve_texture_format

    target_format = None
    if args.format:
        try:
            target_format = resolve_texture_format(args.format)
        except TextureError as exc:
            console.error(str(exc))
            return 2

    try:
        result = repack_bundle(
            args.file,
            args.output,
            args.textures,
            packer=args.packer,
            target_format=target_format,
            allow_resize=args.allow_resize,
            fallback=not args.no_fallback,
            overwrite=args.force,
        )
    except BundleError as exc:
        console.error(str(exc))
        return 1

    report = result.import_report
    for item in report.results:
        label = f"{item.name or '(unnamed)'} [{item.path_id}]"
        if item.status == "ok":
            console.ok(f"{label}: {item.detail}")
        elif item.status == "fallback":
            console.warn(f"{label}: {item.detail}")
        else:
            console.error(f"{label}: {item.detail}")
    for message in report.unmatched_files:
        console.warn(f"Skipped {message}")

    header = result.verify.header
    console.ok(
        f"Saved {args.output} ({result.output_size:,} bytes, "
        f"{header.compression}, {result.verify.object_count} objects)"
    )
    if result.verify.unreadable:
        console.warn(
            f"{len(result.verify.unreadable)} object(s) could not be parsed on "
            f"re-open: {result.verify.unreadable[:10]}"
        )

    zip_code = _maybe_zip(args, args.output)
    if report.failed:
        console.warn(
            f"{report.failed} texture(s) failed; the bundle was saved with the "
            "others replaced."
        )
    return 1 if (report.failed or zip_code) else 0


def cmd_web(args) -> int:
    console.warn("The web UI is not available yet. It is planned for a later stage.")
    return 2


# ---------------------------------------------------------------------------
# Parser
# ---------------------------------------------------------------------------

def _add_zip_option(parser: argparse.ArgumentParser, what: str) -> None:
    parser.add_argument(
        "--zip",
        nargs="?",
        const="",
        default=None,
        metavar="PATH",
        help=f"Also write a ZIP of {what} (default path: <output>.zip)",
    )


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="u3dconv",
        description="Inspect, extract, convert, and repack Unity3D UnityFS bundles.",
    )
    parser.add_argument(
        "--version", action="version", version=f"u3dconv {APP_VERSION}"
    )
    sub = parser.add_subparsers(dest="command", required=True)

    p_info = sub.add_parser("info", help="Show bundle header and object counts")
    p_info.add_argument("file", help="Path to a .bundle / .unity3d file")
    p_info.set_defaults(func=cmd_info)

    p_list = sub.add_parser("list", help="List objects as a tree")
    p_list.add_argument("file")
    p_list.add_argument(
        "--type", nargs="+", metavar="TYPE", help="Only show these object types"
    )
    p_list.add_argument("--json", action="store_true", help="Output JSON")
    p_list.set_defaults(func=cmd_list)

    p_ext = sub.add_parser("extract", help="Extract objects to a folder")
    p_ext.add_argument("file")
    p_ext.add_argument(
        "-o", "--output", help=f"Output folder (default: {DEFAULT_OUTPUT_DIR})"
    )
    p_ext.add_argument(
        "--type", nargs="+", metavar="TYPE", help="Only extract these object types"
    )
    p_ext.add_argument(
        "--raw", action="store_true", help="Write raw bytes for every object"
    )
    _add_zip_option(p_ext, "the extracted folder")
    p_ext.set_defaults(func=cmd_extract)

    p_conv = sub.add_parser(
        "convert", help="Export Texture2D objects to PNG, or list them"
    )
    p_conv.add_argument("file")
    p_conv.add_argument(
        "-o", "--output", help=f"PNG output folder (default: {DEFAULT_TEXTURE_DIR})"
    )
    p_conv.add_argument(
        "--name", nargs="+", metavar="NAME", help="Only export textures with these names"
    )
    p_conv.add_argument(
        "--list", action="store_true", help="Show textures and formats, export nothing"
    )
    _add_zip_option(p_conv, "the exported PNGs")
    p_conv.set_defaults(func=cmd_convert)

    p_rep = sub.add_parser(
        "repack", help="Replace textures from PNGs and save a new bundle"
    )
    p_rep.add_argument("file", help="Source UnityFS bundle (never modified)")
    p_rep.add_argument(
        "--textures", required=True, metavar="DIR",
        help="Folder of PNGs named <name>_<path_id>.png (as written by `convert`)",
    )
    p_rep.add_argument(
        "-o", "--output", required=True, help="Path of the new bundle to write"
    )
    p_rep.add_argument(
        "--packer", choices=PACKER_CHOICES, default=DEFAULT_PACKER,
        help=f"Bundle compression (default: {DEFAULT_PACKER})",
    )
    p_rep.add_argument(
        "--format", metavar="NAME",
        help="Force a TextureFormat for replaced textures (default: keep original)",
    )
    p_rep.add_argument(
        "--allow-resize", action="store_true",
        help="Allow PNGs whose size differs from the original texture",
    )
    p_rep.add_argument(
        "--no-fallback", action="store_true",
        help="Fail instead of falling back to RGBA32 when encoding fails",
    )
    p_rep.add_argument(
        "--force", action="store_true", help="Overwrite the output file if it exists"
    )
    _add_zip_option(p_rep, "the repacked bundle")
    p_rep.set_defaults(func=cmd_repack)

    p_web = sub.add_parser("web", help="Start the local Web UI (not yet available)")
    p_web.add_argument("--host", default="127.0.0.1")
    p_web.add_argument("--port", type=int, default=8765)
    p_web.set_defaults(func=cmd_web)

    return parser


def main(argv: Optional[List[str]] = None) -> int:
    parser = build_parser()
    args = parser.parse_args(argv)
    try:
        return args.func(args)
    except KeyboardInterrupt:
        console.error("Interrupted.")
        return 130
    except Exception as exc:  # last-resort guard: no bare tracebacks by default
        if os.environ.get("U3DCONV_DEBUG"):
            raise
        console.error(f"Unexpected error: {exc} (set U3DCONV_DEBUG=1 for a traceback)")
        return 1


if __name__ == "__main__":
    sys.exit(main())
