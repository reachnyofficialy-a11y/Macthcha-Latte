# UNITY3D-Converter (`u3dconv`)

A Python tool for inspecting, extracting, converting, and repacking Unity3D
UnityFS asset bundles.

Intended for personal inspection and modding of files you own or build
yourself (your own Unity project, or an offline single-player game you have the
right to modify). Do not use it on online multiplayer games or to redistribute
copyrighted assets.

## Status

**Stage 2 – Textures and repacking.**

- Stage 1: UnityFS header parsing, object listing, extraction, `--zip`
- Stage 2: Texture2D to PNG export, PNG import back into textures, bundle
  repacking with LZ4 (or LZMA / none / original), post-save verification

Planned: Wwise `.bnk` handling (Stage 3), local Web UI, iOS packaging via
BeeWare Briefcase.

## Install

Python 3.9 or newer.

```bash
python -m venv .venv
source .venv/bin/activate        # Windows: .venv\Scripts\activate
pip install -r requirements.txt
pip install -e .                 # optional: installs the `u3dconv` command
```

If texture encoding fails with a missing-encoder error, upgrade UnityPy
(`pip install -U UnityPy`) and make sure `etcpak`, `astc-encoder-py`, and
`texture2ddecoder` installed correctly.

## Round-trip workflow

```bash
# 1. See what textures a bundle contains
python -m u3dconv convert my.bundle --list

# 2. Export them as PNG (files are named <name>_<path_id>.png)
python -m u3dconv convert my.bundle -o pngs

# 3. Edit the PNGs in any image editor. Keep the _<path_id> part of each name.

# 4. Write a new bundle with the edited textures (source is never modified)
python -m u3dconv repack my.bundle --textures pngs -o my_modified.bundle

# 5. Optional: also get a ZIP, handy for sharing from a phone
python -m u3dconv repack my.bundle --textures pngs -o my_modified.bundle --zip
```

### `repack` options

| Option | Meaning |
| --- | --- |
| `--packer {original,lz4,lzma,none}` | Compression of the new bundle (default `lz4`) |
| `--format NAME` | Force a UnityPy `TextureFormat` (for example `RGBA32`). Default keeps each texture's original format |
| `--allow-resize` | Accept PNGs whose size differs from the original texture. Off by default because game code may depend on texture size |
| `--no-fallback` | Fail instead of falling back to RGBA32 when the original format cannot be encoded |
| `--force` | Overwrite the output file if it exists |
| `--zip [PATH]` | Also write a ZIP of the result |

### How files are matched

A PNG is matched to a texture by the number at the end of its file name
(`hero_123.png` matches path ID 123). You can rename the part before it. A file
with no number matches by texture name, but only if exactly one texture has
that name. Anything unmatched is reported and skipped.

### Safety behavior

- The source bundle is never modified. Output goes to a new path, and the tool
  refuses to write over the input.
- The bundle is written to a temporary file and moved into place, so a failed
  save leaves no partial file.
- After saving, the new bundle is re-opened: the header must be valid UnityFS,
  the object count must match, and every object must parse. If that check fails
  the output is deleted.
- Each texture is processed independently. One failure does not stop the others,
  and the exit code is 1 if any texture failed.
- If encoding to the original GPU format (ASTC, ETC2, PVRTC, ...) fails, the
  texture is saved as uncompressed RGBA32 and a warning is shown. This works
  everywhere but uses more memory.

Verification proves the bundle is structurally sound. It cannot prove a
particular game or Unity version will accept it, so test in your own project.

## Other commands

```bash
python -m u3dconv info my.bundle
python -m u3dconv list my.bundle --type Texture2D --json
python -m u3dconv extract my.bundle -o out --zip
```

## Tests

```bash
python -m unittest discover -s tests -v
```

The tests use fake objects in place of UnityPy, so they check u3dconv's own
logic without needing a bundle. They do not exercise UnityPy's encoders.

## Project layout

```
pyproject.toml, requirements.txt, LICENSE
u3dconv/
  __init__.py     package metadata
  __main__.py     `python -m u3dconv` entry point
  constants.py    signatures, compression, packers, texture formats
  bundle.py       header parsing, listing, extraction, save/verify/repack
  textures.py     PNG export, PNG import, format handling and fallback
  tree.py         grouped tree rendering and serialization
  console.py      status lines and tables
  cli.py          commands and ZIP export
tests/
  test_stage2.py
```

## License

MIT. See `LICENSE`.
